import React from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";
import "./icons.js";
import DeleteInfo from "./screens/DeleteInfo";
import Home from "./screens/Home";
import Login from "./screens/Login";
import PatientDatabase from "./screens/PatientDatabase";
import PatientInfo from "./screens/PatientInfo";
import Settings from "./screens/Settings";
import UpdateInfo from "./screens/UpdateInfo";
import "./style.css";

function App() {
  return (
    <Router>
      <Route path="/" exact component={DeleteInfo} />
      <Route path="/DeleteInfo/" exact component={DeleteInfo} />
      <Route path="/Home/" exact component={Home} />
      <Route path="/Login/" exact component={Login} />
      <Route path="/PatientDatabase/" exact component={PatientDatabase} />
      <Route path="/PatientInfo/" exact component={PatientInfo} />
      <Route path="/Settings/" exact component={Settings} />
      <Route path="/UpdateInfo/" exact component={UpdateInfo} />
    </Router>
  );
}

export default App;
